﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;

namespace VoiceSynthesizer
{
    public static class VoiceSynthesizer
    {
        [DllImport("lib/VoiceSynth_win32.dll", EntryPoint = "main", CharSet = CharSet.Ansi,
            CallingConvention = CallingConvention.Cdecl)]
        static extern int SynthesizeWrap(int argc, string[] argv);

        public static void SynthesizeVoice(string inputText, string outputFileName, double speed)
        {
            if (!Directory.Exists("lib"))
            {
                Directory.CreateDirectory("lib");
            }
            if (!File.Exists("lib/VoiceSynth.dll"))
            {
                using var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("VoiceSynthesizer.lib.VoiceSynth_win32.dll");
                using var fileStream = new FileStream("lib/VoiceSynth.dll", FileMode.Create);
                var bytes = new byte[stream.Length];
                stream.Read(bytes, 0, bytes.Length);
                fileStream.Write(bytes, 0, bytes.Length);
            }

            File.WriteAllText("VoiceSynth/synthesizable.txt", inputText);

            var arguments = new[]
            {
                "-f", "VoiceSynth/synthesizable.txt",
                "-o", outputFileName,
                "-r", $"{speed}",
                "-lex", @".\Resources\et.dct",
                "-lexd", @".\Resources\et3.dct",
                "-m", @".\Resources\eki_et_tnu.htsvoice"
            };

            SynthesizeWrap(arguments.Length, arguments);
        }
    }
}
